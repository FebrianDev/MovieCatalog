package com.febrian.moviecatalog.data.model

data class Genre(
    var id: Int? = null,
    var name: String? = null
)